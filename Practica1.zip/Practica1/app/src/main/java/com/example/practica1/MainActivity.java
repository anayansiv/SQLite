package com.example.practica1;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private SQLiteHelper dbHelper;
    private EditText editTextId, editTextNombre, editTextEmail, editTextEdad;
    private Button btnAgregar, btnBuscar, btnActualizar, btnEliminar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupListeners();
    }

    private void initializeViews() {
        dbHelper = new SQLiteHelper(this);
        editTextId = findViewById(R.id.editTextId);
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextEdad = findViewById(R.id.editTextEdad);
        btnAgregar = findViewById(R.id.btnAgregar);
        btnBuscar = findViewById(R.id.btnBuscar);
        btnActualizar = findViewById(R.id.btnActualizar);
        btnEliminar = findViewById(R.id.btnEliminar);
    }

    private void setupListeners() {
        btnAgregar.setOnClickListener(v -> agregarUsuario());
        btnBuscar.setOnClickListener(v -> buscarUsuario());
        btnActualizar.setOnClickListener(v -> actualizarUsuario());
        btnEliminar.setOnClickListener(v -> eliminarUsuario());
    }

    private void agregarUsuario() {
        String nombre = editTextNombre.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String edadStr = editTextEdad.getText().toString().trim();

        if (nombre.isEmpty() || email.isEmpty() || edadStr.isEmpty()) {
            mostrarMensaje("Por favor, complete todos los campos");
            return;
        }

        try {
            int edad = Integer.parseInt(edadStr);
            dbHelper.addUsuario(nombre, email, edad);
            limpiarCampos();
            mostrarMensaje("Usuario agregado exitosamente");
        } catch (NumberFormatException e) {
            mostrarMensaje("Por favor ingrese una edad válida");
        }
    }

    private void buscarUsuario() {
        String idStr = editTextId.getText().toString().trim();
        if (idStr.isEmpty()) {
            mostrarMensaje("Por favor, ingrese un ID");
            return;
        }

        try {
            int id = Integer.parseInt(idStr);
            Cursor cursor = dbHelper.getUsuario(id);
            if (cursor != null && cursor.moveToFirst()) {
                editTextNombre.setText(cursor.getString(cursor.getColumnIndex("nombre")));
                editTextEmail.setText(cursor.getString(cursor.getColumnIndex("email")));
                editTextEdad.setText(String.valueOf(cursor.getInt(cursor.getColumnIndex("edad"))));
                cursor.close();
            } else {
                mostrarMensaje("Usuario no encontrado");
                limpiarCampos();
            }
        } catch (NumberFormatException e) {
            mostrarMensaje("Por favor ingrese un ID válido");
        }
    }

    private void actualizarUsuario() {
        String idStr = editTextId.getText().toString().trim();
        String nombre = editTextNombre.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String edadStr = editTextEdad.getText().toString().trim();

        if (idStr.isEmpty() || nombre.isEmpty() || email.isEmpty() || edadStr.isEmpty()) {
            mostrarMensaje("Por favor, complete todos los campos");
            return;
        }

        try {
            int id = Integer.parseInt(idStr);
            int edad = Integer.parseInt(edadStr);
            dbHelper.updateUsuario(id, nombre, email, edad);
            limpiarCampos();
            mostrarMensaje("Usuario actualizado exitosamente");
        } catch (NumberFormatException e) {
            mostrarMensaje("Por favor ingrese datos válidos");
        }
    }

    private void eliminarUsuario() {
        String idStr = editTextId.getText().toString().trim();
        if (idStr.isEmpty()) {
            mostrarMensaje("Por favor, ingrese un ID");
            return;
        }

        try {
            int id = Integer.parseInt(idStr);
            dbHelper.deleteUsuario(id);
            limpiarCampos();
            mostrarMensaje("Usuario eliminado exitosamente");
        } catch (NumberFormatException e) {
            mostrarMensaje("Por favor ingrese un ID válido");
        }
    }

    private void limpiarCampos() {
        editTextId.setText("");
        editTextNombre.setText("");
        editTextEmail.setText("");
        editTextEdad.setText("");
    }

    private void mostrarMensaje(String mensaje) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
}